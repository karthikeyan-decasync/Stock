import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-example-bootstrap',
  templateUrl: './tutorial.component.html',
  styleUrls: ['./tutorial.component.css']
})
export class TutorialComponent {

  constructor() {
  }

}
