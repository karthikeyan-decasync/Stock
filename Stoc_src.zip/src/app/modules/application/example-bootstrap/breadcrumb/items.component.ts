import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-breadcrumb',
  templateUrl: './items.component.html',
  styleUrls: ['./items.component.css']
})
export class BreadcrumbComponent {

  constructor() { }

}
