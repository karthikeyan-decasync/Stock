import { Component } from '@angular/core';

@Component({
  selector: 'app-loader',
  templateUrl: './main.html',
  styleUrls: ['./main.scss']
})
export class LoaderComponent {

  constructor() { }

}
