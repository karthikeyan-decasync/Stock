

import { Component } from '@angular/core';

@Component({
  selector: 'app-report-main',
  templateUrl: './main.html',
  styleUrls: ['./main.scss']
})
export class ReportMainComponent {

  constructor() { }

}
