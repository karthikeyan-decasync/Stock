export interface User 
{
id : number,
user_name: string,
Role: string,
name_of_user : string
}

