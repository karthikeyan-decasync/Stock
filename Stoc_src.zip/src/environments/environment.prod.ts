export const environment = {
  production: true,
  application:
  {
    name: 'angular-starter',
    version: 'Angular 14.2.5',
    bootstrap: 'Bootstrap 5.2.2',
    fontawesome: 'Font Awesome 6.2.0',
  }
};